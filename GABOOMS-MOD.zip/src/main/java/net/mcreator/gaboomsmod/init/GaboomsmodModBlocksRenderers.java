/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gaboomsmod.init;

import net.mcreator.gaboomsmod.block.*;

import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

@Environment(EnvType.CLIENT)
public class GaboomsmodModBlocksRenderers {
	public static void clientLoad() {
		StrawberryCakeBlock.registerRenderLayer();
		StrawberryCake1BBlock.registerRenderLayer();
		StrawberryCake2BBlock.registerRenderLayer();
		StrawberryCake3BBlock.registerRenderLayer();
		StrawberryCake4BBlock.registerRenderLayer();
		StrawberryCake5BBlock.registerRenderLayer();
		StrawberryCake6BBlock.registerRenderLayer();
		StrawberryBushBlock.registerRenderLayer();
		StrawberryBush2Block.registerRenderLayer();
		StrawberryBush3Block.registerRenderLayer();
		StrawberryBush4Block.registerRenderLayer();
	}
	// Start of user code block custom block renderers
	// End of user code block custom block renderers
}