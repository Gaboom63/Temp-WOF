/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gaboomsmod.init;

import net.minecraft.world.item.CreativeModeTabs;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;

public class GaboomsmodModTabs {
	public static void load() {
		ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.FOOD_AND_DRINKS).register(tabData -> {
			tabData.accept(GaboomsmodModBlocks.STRAWBERRY_CAKE.asItem());
			tabData.accept(GaboomsmodModItems.STRAWBERRY_JAM);
			tabData.accept(GaboomsmodModItems.STRAWBERRY);
			tabData.accept(GaboomsmodModItems.JAMONTOAST);
		});
	}
}