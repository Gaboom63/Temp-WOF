/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gaboomsmod.init;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Block;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.gaboomsmod.block.*;
import net.mcreator.gaboomsmod.GaboomsmodMod;

import java.util.function.Function;

public class GaboomsmodModBlocks {
	public static Block STRAWBERRY_CAKE;
	public static Block STRAWBERRY_CAKE_1_B;
	public static Block STRAWBERRY_CAKE_2_B;
	public static Block STRAWBERRY_CAKE_3_B;
	public static Block STRAWBERRY_CAKE_4_B;
	public static Block STRAWBERRY_CAKE_5_B;
	public static Block STRAWBERRY_CAKE_6_B;
	public static Block STRAWBERRY_BUSH;
	public static Block STRAWBERRY_BUSH_2;
	public static Block STRAWBERRY_BUSH_3;
	public static Block STRAWBERRY_BUSH_4;

	public static void load() {
		STRAWBERRY_CAKE = register("strawberry_cake", StrawberryCakeBlock::new);
		STRAWBERRY_CAKE_1_B = register("strawberry_cake_1_b", StrawberryCake1BBlock::new);
		STRAWBERRY_CAKE_2_B = register("strawberry_cake_2_b", StrawberryCake2BBlock::new);
		STRAWBERRY_CAKE_3_B = register("strawberry_cake_3_b", StrawberryCake3BBlock::new);
		STRAWBERRY_CAKE_4_B = register("strawberry_cake_4_b", StrawberryCake4BBlock::new);
		STRAWBERRY_CAKE_5_B = register("strawberry_cake_5_b", StrawberryCake5BBlock::new);
		STRAWBERRY_CAKE_6_B = register("strawberry_cake_6_b", StrawberryCake6BBlock::new);
		STRAWBERRY_BUSH = register("strawberry_bush", StrawberryBushBlock::new);
		STRAWBERRY_BUSH_2 = register("strawberry_bush_2", StrawberryBush2Block::new);
		STRAWBERRY_BUSH_3 = register("strawberry_bush_3", StrawberryBush3Block::new);
		STRAWBERRY_BUSH_4 = register("strawberry_bush_4", StrawberryBush4Block::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> B register(String name, Function<BlockBehaviour.Properties, B> supplier) {
		return (B) Blocks.register(ResourceKey.create(Registries.BLOCK, ResourceLocation.fromNamespaceAndPath(GaboomsmodMod.MODID, name)), (Function<BlockBehaviour.Properties, Block>) supplier, BlockBehaviour.Properties.of());
	}
}