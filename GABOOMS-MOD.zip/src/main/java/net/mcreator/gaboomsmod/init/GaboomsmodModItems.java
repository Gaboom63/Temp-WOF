/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.gaboomsmod.init;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.gaboomsmod.item.*;
import net.mcreator.gaboomsmod.GaboomsmodMod;

import java.util.function.Function;

public class GaboomsmodModItems {
	public static Item STRAWBERRY_CAKE;
	public static Item STRAWBERRY_JAM;
	public static Item STRAWBERRY;
	public static Item JAMONTOAST;
	public static Item STRAWBERRY_MILK;
	public static Item CHOCOLATE_MILK;
	public static Item CHERRY;
	public static Item STRAWBERRY_MILK_BOTTLE;
	public static Item CHOCOLATE_MILK_BOTTLE;
	public static Item CHERRY_PASTRY;

	public static void load() {
		STRAWBERRY_CAKE = block(GaboomsmodModBlocks.STRAWBERRY_CAKE, "strawberry_cake");
		STRAWBERRY_JAM = register("strawberry_jam", StrawberryJamItem::new);
		STRAWBERRY = register("strawberry", StrawberryItem::new);
		JAMONTOAST = register("jamontoast", JamontoastItem::new);
		STRAWBERRY_MILK = register("strawberry_milk", StrawberryMilkItem::new);
		CHOCOLATE_MILK = register("chocolate_milk", ChocolateMilkItem::new);
		CHERRY = register("cherry", CherryItem::new);
		STRAWBERRY_MILK_BOTTLE = register("strawberry_milk_bottle", StrawberryMilkBottleItem::new);
		CHOCOLATE_MILK_BOTTLE = register("chocolate_milk_bottle", ChocolateMilkBottleItem::new);
		CHERRY_PASTRY = register("cherry_pastry", CherryPastryItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> I register(String name, Function<Item.Properties, ? extends I> supplier) {
		return (I) Items.registerItem(ResourceKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(GaboomsmodMod.MODID, name)), (Function<Item.Properties, Item>) supplier);
	}

	private static Item block(Block block, String name) {
		return block(block, name, new Item.Properties());
	}

	private static Item block(Block block, String name, Item.Properties properties) {
		return Items.registerItem(ResourceKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(GaboomsmodMod.MODID, name)), prop -> new BlockItem(block, prop), properties);
	}
}