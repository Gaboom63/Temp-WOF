package net.mcreator.gaboomsmod.procedures;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.gaboomsmod.init.GaboomsmodModItems;
import net.mcreator.gaboomsmod.init.GaboomsmodModBlocks;

public class StrawberryBushPlantRightclickedProcedure {
	public static boolean eventResult = true;

	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (world instanceof ServerLevel _level) {
			ItemEntity entityToSpawn_0 = new ItemEntity(_level, x, y, z, new ItemStack(GaboomsmodModItems.STRAWBERRY));
			entityToSpawn_0.setPickUpDelay(10);
			_level.addFreshEntity(entityToSpawn_0);
		}
		{
			BlockPos _bp1 = BlockPos.containing(x, y, z);
			BlockState _bs1 = GaboomsmodModBlocks.STRAWBERRY_BUSH_2.defaultBlockState();
			BlockState _bso = world.getBlockState(_bp1);
			for (Property<?> _propertyOld : _bso.getProperties()) {
				Property _propertyNew = _bs1.getBlock().getStateDefinition().getProperty(_propertyOld.getName());
				if (_propertyNew != null && _bs1.getValue(_propertyNew) != null)
					try {
						_bs1 = _bs1.setValue(_propertyNew, _bso.getValue(_propertyOld));
					} catch (Exception e) {
					}
			}
			world.setBlock(_bp1, _bs1, 3);
		}
	}
}