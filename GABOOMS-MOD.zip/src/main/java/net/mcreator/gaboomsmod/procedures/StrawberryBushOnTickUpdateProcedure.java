package net.mcreator.gaboomsmod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.gaboomsmod.init.GaboomsmodModBlocks;

public class StrawberryBushOnTickUpdateProcedure {
	public static boolean eventResult = true;

	public static void execute(LevelAccessor world, double x, double y, double z) {
		double RandomNumber = 0;
		RandomNumber = Math.random() * 100;
		if (RandomNumber <= 5) {
			world.setBlock(BlockPos.containing(x, y, z), GaboomsmodModBlocks.STRAWBERRY_BUSH_2.defaultBlockState(), 3);
		}
	}
}