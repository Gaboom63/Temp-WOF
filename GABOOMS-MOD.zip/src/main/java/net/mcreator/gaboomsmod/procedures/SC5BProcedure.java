package net.mcreator.gaboomsmod.procedures;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.GameType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.Minecraft;

import net.mcreator.gaboomsmod.init.GaboomsmodModBlocks;

public class SC5BProcedure {
	public static boolean eventResult = true;

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (getEntityGameType(entity) == GameType.CREATIVE) {
			{
				BlockPos _bp1 = BlockPos.containing(x, y, z);
				BlockState _bs1 = GaboomsmodModBlocks.STRAWBERRY_CAKE_6_B.defaultBlockState();
				BlockState _bso = world.getBlockState(_bp1);
				for (Property<?> _propertyOld : _bso.getProperties()) {
					Property _propertyNew = _bs1.getBlock().getStateDefinition().getProperty(_propertyOld.getName());
					if (_propertyNew != null && _bs1.getValue(_propertyNew) != null)
						try {
							_bs1 = _bs1.setValue(_propertyNew, _bso.getValue(_propertyOld));
						} catch (Exception e) {
						}
				}
				world.setBlock(_bp1, _bs1, 3);
			}
		} else if ((entity instanceof Player _plr ? _plr.getFoodData().getFoodLevel() : 0) < 20) {
			if (entity instanceof Player _player) {
				_player.getFoodData().setFoodLevel((entity instanceof Player _plr ? _plr.getFoodData().getFoodLevel() : 0) + 2);
			}
			{
				BlockPos _bp5 = BlockPos.containing(x, y, z);
				BlockState _bs5 = GaboomsmodModBlocks.STRAWBERRY_CAKE_6_B.defaultBlockState();
				BlockState _bso = world.getBlockState(_bp5);
				for (Property<?> _propertyOld : _bso.getProperties()) {
					Property _propertyNew = _bs5.getBlock().getStateDefinition().getProperty(_propertyOld.getName());
					if (_propertyNew != null && _bs5.getValue(_propertyNew) != null)
						try {
							_bs5 = _bs5.setValue(_propertyNew, _bso.getValue(_propertyOld));
						} catch (Exception e) {
						}
				}
				world.setBlock(_bp5, _bs5, 3);
			}
		}
	}

	private static GameType getEntityGameType(Entity entity) {
		if (entity instanceof ServerPlayer serverPlayer) {
			return serverPlayer.gameMode.getGameModeForPlayer();
		} else if (entity instanceof Player player && player.level().isClientSide()) {
			PlayerInfo playerInfo = Minecraft.getInstance().getConnection().getPlayerInfo(player.getGameProfile().getId());
			if (playerInfo != null)
				return playerInfo.getGameMode();
		}
		return null;
	}
}