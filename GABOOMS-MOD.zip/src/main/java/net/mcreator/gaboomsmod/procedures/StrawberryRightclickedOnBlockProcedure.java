package net.mcreator.gaboomsmod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.GameType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.Minecraft;

import net.mcreator.gaboomsmod.init.GaboomsmodModItems;
import net.mcreator.gaboomsmod.init.GaboomsmodModBlocks;

public class StrawberryRightclickedOnBlockProcedure {
	public static boolean eventResult = true;

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (world.isEmptyBlock(BlockPos.containing(x, y, z)) == false) {
			if (!((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == GaboomsmodModBlocks.STRAWBERRY_BUSH || (world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == GaboomsmodModBlocks.STRAWBERRY_BUSH_2
					|| (world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == GaboomsmodModBlocks.STRAWBERRY_BUSH_3 || (world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == GaboomsmodModBlocks.STRAWBERRY_BUSH_4) == true) {
				if (world.isEmptyBlock(BlockPos.containing(x, y + 1, z)) == true && world.getBlockState(BlockPos.containing(x, y, z)).canOcclude()) {
					world.setBlock(BlockPos.containing(x, y + 1, z), GaboomsmodModBlocks.STRAWBERRY_BUSH.defaultBlockState(), 3);
					if (getEntityGameType(entity) == GameType.SURVIVAL) {
						if (entity instanceof Player _player) {
							ItemStack _stktoremove13 = new ItemStack(GaboomsmodModItems.STRAWBERRY);
							_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove13.getItem() == p.getItem(), 1, _player.inventoryMenu.getCraftSlots());
						}
					}
				}
			}
		}
	}

	private static GameType getEntityGameType(Entity entity) {
		if (entity instanceof ServerPlayer serverPlayer) {
			return serverPlayer.gameMode.getGameModeForPlayer();
		} else if (entity instanceof Player player && player.level().isClientSide()) {
			PlayerInfo playerInfo = Minecraft.getInstance().getConnection().getPlayerInfo(player.getGameProfile().getId());
			if (playerInfo != null)
				return playerInfo.getGameMode();
		}
		return null;
	}
}