package net.mcreator.gaboomsmod.procedures;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.gaboomsmod.init.GaboomsmodModBlocks;

public class StrawberryBushOnBoneMealSuccessProcedure {
	public static boolean eventResult = true;

	public static void execute(LevelAccessor world, double x, double y, double z) {
		{
			BlockPos _bp0 = BlockPos.containing(x, y, z);
			BlockState _bs0 = GaboomsmodModBlocks.STRAWBERRY_BUSH_2.defaultBlockState();
			BlockState _bso = world.getBlockState(_bp0);
			for (Property<?> _propertyOld : _bso.getProperties()) {
				Property _propertyNew = _bs0.getBlock().getStateDefinition().getProperty(_propertyOld.getName());
				if (_propertyNew != null && _bs0.getValue(_propertyNew) != null)
					try {
						_bs0 = _bs0.setValue(_propertyNew, _bso.getValue(_propertyOld));
					} catch (Exception e) {
					}
			}
			world.setBlock(_bp0, _bs0, 3);
		}
	}
}