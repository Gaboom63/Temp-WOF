package net.mcreator.gaboomsmod.block;

import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.FlowerBlock;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.util.RandomSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.BlockPos;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;

import net.mcreator.gaboomsmod.procedures.StrawberryBushOnTickUpdateProcedure;
import net.mcreator.gaboomsmod.procedures.StrawberryBushOnBoneMealSuccessOGProcedure;
import net.mcreator.gaboomsmod.init.GaboomsmodModBlocks;

import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectionContext;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

import java.util.function.Predicate;

public class StrawberryBushBlock extends FlowerBlock implements BonemealableBlock {
	public StrawberryBushBlock(BlockBehaviour.Properties properties) {
		super(MobEffects.OOZING, 100, properties.mapColor(MapColor.PLANT).randomTicks().sound(SoundType.SWEET_BERRY_BUSH).instabreak().noCollission().ignitedByLava().offsetType(BlockBehaviour.OffsetType.XZ).pushReaction(PushReaction.DESTROY));
		FlammableBlockRegistry.getDefaultInstance().add(this, 100, 60);
	}

	@Environment(EnvType.CLIENT)
	public static void registerRenderLayer() {
		BlockRenderLayerMap.putBlock(GaboomsmodModBlocks.STRAWBERRY_BUSH, ChunkSectionLayer.CUTOUT);
	}

	public static final Predicate<BiomeSelectionContext> GENERATE_BIOMES = BiomeSelectors.includeByKey(ResourceKey.create(Registries.BIOME, ResourceLocation.parse("meadow")),
			ResourceKey.create(Registries.BIOME, ResourceLocation.parse("old_growth_spruce_taiga")), ResourceKey.create(Registries.BIOME, ResourceLocation.parse("taiga")),
			ResourceKey.create(Registries.BIOME, ResourceLocation.parse("old_growth_pine_taiga")), ResourceKey.create(Registries.BIOME, ResourceLocation.parse("plains")));

	@Override
	public ItemStack getCloneItemStack(LevelReader world, BlockPos pos, BlockState state, boolean includeData) {
		return ItemStack.EMPTY;
	}

	@Override
	public void randomTick(BlockState blockstate, ServerLevel world, BlockPos pos, RandomSource random) {
		StrawberryBushOnTickUpdateProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}

	@Override
	public boolean isValidBonemealTarget(LevelReader worldIn, BlockPos pos, BlockState blockstate) {
		return true;
	}

	@Override
	public boolean isBonemealSuccess(Level world, RandomSource random, BlockPos pos, BlockState blockstate) {
		return true;
	}

	@Override
	public void performBonemeal(ServerLevel world, RandomSource random, BlockPos pos, BlockState blockstate) {
		StrawberryBushOnBoneMealSuccessOGProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ());
	}
}